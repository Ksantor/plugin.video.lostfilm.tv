# plugin.video.lostfilm.tv
LostFilm.tv addon for Kodi.tv (Fork)

Это форк оригинального плагина от [anteo](https://github.com/anteo/plugin.video.lostfilm.tv).

На данный момент оригинальная версия плагина не работает. Данная версия частичто переработана и представляет собой MVP (minimum valuable product).

**Протестирован на свежих версиях Kodi 16.1/17.0**

**Возможно для корректной работы плагина будет необходимо очистить кэш Koid**

**Плагин берёт сериалы добавленные в личную библиотеку на сайте [lostfilm.tv](lostfilm.tv), по этому для работы плагина обязателен аккаунт.**

* Залогиньтесь в свою учётную запись на lostfilm.tv
* Добавьте интересующие вас сериалы в "избранное" (если вы этого уже не сделали)
* Откройте Kodi
* Установите сперва [script.module.torrent2http-0.1.0.zip](https://github.com/Ksantor/plugin.video.lostfilm.tv/blob/master/script.module.torrent2http-0.1.0.zip)
* Потом сам [плагин](https://github.com/Ksantor/plugin.video.lostfilm.tv/blob/master/plugin.video.lostfilm.tv-0.1.2.zip)
* В настройках плагина введите ваш логин и пароль от сайта **lostfilm.tv**
* Пользуйтесь

Из плагина удалена часть дополнительного функционала - добавления сериала в локальную библиотеку, использование прокси серверов, скачивание эпизодов по запросу и т.д.
