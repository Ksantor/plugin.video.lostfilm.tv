# -*- coding: utf-8 -*-

import datetime
import time

from collections import namedtuple
from support.plugin import plugin
from common.helpers import poster, fanart_image, color

class Episode(namedtuple('Episode', ['serie_id', 'serie_code', 'season_number',
  'episode_number', 'title_en', 'title_ru', 'date', 'rating', 'watched'])):
  def item(self):
    return {
      'label': self.list_title,
      'path': self.episode_url,
      'is_playable': True,
      'thumbnail': poster(self.serie_id, self.season_number),
      'icon': None,
      'properties': {
          'fanart_image': fanart_image(self.serie_id),
      },
      'info': {
          'title': self.title,
          'originaltitle': self.title_en,
          'premiered': self.episode_date,
          'plot': None,
          'rating': self.rating,
          'studio': None,
          'castandrole': [],
          'writer': None,
          'director': None,
          'genre': None,
          'tvshowtitle': None,
          'year': None,
      }
    }

  @property
  def episode_url(self):
    return plugin.url_for('play_episode',
      serie_id = self.serie_id,
      season_number = self.season_number,
      episode_number = self.episode_number,
      select_quality = True
    )

  @property
  def episode_date(self):
    date = datetime.date(*(time.strptime(self.date, '%d.%m.%Y')[0:3]))
    return date.strftime('%Y-%m-%d')

  @property
  def list_title(self):
    if self.watched:
      return self.title
    else:
      return color(self.title, 'lime')

  @property
  def title(self):
    if plugin.get_setting('show-original-title', bool):
      return self.episode_number + '  -  ' + self.title_en
    else:
      return self.episode_number + '  -  ' + self.title_ru
