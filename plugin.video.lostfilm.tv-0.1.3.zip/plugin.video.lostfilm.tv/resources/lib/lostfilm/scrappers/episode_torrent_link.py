# -*- coding: utf-8 -*-

import logging
import re
import CommonFunctions

from collections import namedtuple
from xbmcswift2 import xbmcgui
from support.plugin import plugin
from common.network_request import NetworkRequest
from common.helpers import color, human_size

class EpisodeTorrentLink(object):
  def __init__(self, serie_id, season_number, episode_number, select_quality = False):
    self.network_request = NetworkRequest()
    self.parsedom = CommonFunctions
    self.serie_id = serie_id
    self.season_number = season_number
    self.episode_number = episode_number
    self.select_quality = select_quality

  def link(self):
    links = self.link()

    qualities = sorted(Quality)
    quality = plugin.get_setting('quality', int)

    ordered_links = [next((l for l in links if l.quality == q), None) for q in qualities]

    if not quality or select_quality or not ordered_links[quality - 1]:
      filtered_links = [l for l in ordered_links if l]
      if not filtered_links:
        return
      options = ["%s / %s" % (color(l.quality.localized, 'white'), human_size(l.size)) for l in filtered_links]
      res = xbmcgui.Dialog().select(plugin.get_string(40400), options)
      if res < 0:
        return
      return filtered_links[res]
    else:
      return ordered_links[quality - 1]

    return links

  def links(self):
    links = []
    TorrentLink = namedtuple('TorrentLink', ['quality', 'url', 'size'])
    url = self.network_request.base_url + \
      '/v_search.php?c=%s&s=%s&e=%s' % (self.serie_id, self.season_number, self.episode_number)

    response = self.network_request.get(url)
    redirect_url = self.parsedom.parseDOM(response.text, 'a', ret = 'href')

    response = self.network_request.get(redirect_url[0])
    links_list = self.parsedom.parseDOM(response.text,
      'div', attrs = { 'class': 'inner-box--list' })

    link_items = self.parsedom.parseDOM(links_list,
      'div', attrs = { 'class': 'inner-box--item' })

    for link_item in link_items:
      quality = self.parsedom.parseDOM(link_item,
        'div', attrs = { 'class': 'inner-box--label' })

      link_item_div = self.parsedom.parseDOM(link_item,
        'div', attrs = { 'class': 'inner-box--link sub' })
      href = self.parsedom.parseDOM(link_item_div[0], 'a', ret = 'href')

      link_desc = self.parsedom.parseDOM(link_item,
        'div', attrs = { 'class': 'inner-box--desc' })

      size = re.search('(\d+\.\d+)', link_desc[0]).group(1)

      links.append(TorrentLink(quality[0], href[0], self.parse_size(size)))

    return links

  def parse_size(self, size):
    if len(size) == 4:
      return long(float(size) * 1024 * 1024 * 1024)
    else:
      return long(float(size) * 1024 * 1024)
