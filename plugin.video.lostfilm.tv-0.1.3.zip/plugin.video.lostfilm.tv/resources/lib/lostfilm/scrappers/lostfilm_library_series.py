# -*- coding: utf-8 -*-

import logging
import re
import CommonFunctions

from common.network_request import NetworkRequest
from lostfilm.models.serie import Serie

class LostfilmLibrarySeries(object):
  def __init__(self):
    self.network_request = NetworkRequest()
    self.parsedom = CommonFunctions

  def list(self):
    series_list_items = []

    url = self.network_request.base_url + '/my/type_1'
    response = self.network_request.get(url)
    series = self.serial_rows(response.text)

    for serie in series:
      title_en, title_ru = self.serie_titles(serie)
      total_episodes_count, watched_episodes_count = self.series_episode_count(serie)

      serie_data = [
        self.serie_id(serie),
        self.serie_code(serie),
        title_en,
        title_ru,
        total_episodes_count,
        watched_episodes_count
      ]

      series_list_items.append(Serie(*serie_data).item())

    return series_list_items

  def serial_rows(self, dom):
    serials_list_box = self.parsedom.parseDOM(dom,
      'div', attrs = { 'class': 'serials-list-box' })
    rows = self.parsedom.parseDOM(serials_list_box,
      'div', attrs = { 'class': 'serial-box' })
    return rows

  def serie_id(self, dom):
    id_attr = self.parsedom.parseDOM(dom,
      'div', attrs = { 'class': 'subscribe-box' }, ret = 'id')

    if not id_attr:
      id_attr = self.parsedom.parseDOM(dom,
        'div', attrs = { 'class': 'subscribe-box active' }, ret = 'id')

    series_id = re.search('(\d+)', id_attr[0]) if id_attr[0] else ''
    return series_id.group(1) if series_id else 000

  def serie_code(self, dom):
    href_attr = self.parsedom.parseDOM(dom,
      'a', attrs = { 'href': '/series/.+?', 'class': 'body' }, ret = 'href')
    series_code = re.search('([^/]+$)', href_attr[0]) if href_attr[0] else ''

    return series_code.group(1) if series_code else ''

  def serie_titles(self, dom):
    link = self.parsedom.parseDOM(dom,
      'a', attrs = { 'href': '/series/.+?', 'class': 'body' })
    title_en = self.parsedom.parseDOM(link,
      'div', attrs = { 'class': 'title-en' })
    title_ru = self.parsedom.parseDOM(link,
      'div', attrs = { 'class': 'title-ru' })

    return title_en[0].encode('utf-8'), title_ru[0].encode('utf-8')

  def series_episode_count(self, dom):
    episode_bar_pane = self.parsedom.parseDOM(dom,
      'div', attrs = { 'class': 'bar-pane' })

    total_episodes_bar = self.parsedom.parseDOM(episode_bar_pane,
      'div', attrs = { 'class': 'bar' })
    total_episodes_count = self.parsedom.parseDOM(total_episodes_bar,
      'div', attrs = { 'class': 'value' })
    if total_episodes_count[0] == '':
      total_episodes_count[0] = 0

    watched_episodes_bar = self.parsedom.parseDOM(episode_bar_pane,
      'div', attrs = { 'class': 'bar-active' })
    watched_episodes_count = self.parsedom.parseDOM(watched_episodes_bar,
      'div', attrs = { 'class': 'value' })
    if watched_episodes_count[0] == '':
      watched_episodes_count[0] = 0

    return total_episodes_count[0], watched_episodes_count[0]
